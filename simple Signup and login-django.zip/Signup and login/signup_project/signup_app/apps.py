from django.apps import AppConfig


class SignupAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'signup_app'

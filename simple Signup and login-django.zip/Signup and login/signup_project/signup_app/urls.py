from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.login, name = "login page"),
    path("login", views.login, name="login"),
    path("login2", views.main_login, name="login2"),
    path("signup/", views.signup, name="signup"),
    path('home/', views.home, name="home"),
    # path("accounts/", include("django.contrib.auth.urls")),
]
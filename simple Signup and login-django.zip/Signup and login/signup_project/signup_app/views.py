from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login as auth_login



def home(request): 
    return render(request, "home.html", {})

def login(request):
    try:
        if request.method == "POST":
            username = request.POST['username']
            password = request.POST['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                auth_login(request, user)
                return redirect('home')  # Redirect to home page after login
            else:
                messages.error(request, "Invalid username or password")
        return render(request, 'login.html')
    except Exception as e:
        messages.error(request, f"An error occoured: {e}")
        return render(request, 'login.html')

# def login(request):
#     return render(request, "login.html", {})

def main_login(request):    
    return render(request, "login2.html", {})
    

def signup(request):
    try:
        if request.method == "POST":
            username = request.POST['username']
            password1 = request.POST['password1']
            password2 = request.POST['password2']

            if password1 != password2:
                messages.error(request, "password didnot match.")
                return render(request, 'signup.html')

            if User.objects.filter (username = username).exists():
                messages.error(request, "username already exists")
                return render(request, 'signup.html')

            user = User.objects.create_user(username = username, password = password1)
            user.save()
            return redirect('login2')
        return render(request, 'signup.html')
    except Exception as e:
        messages.error(request, f"An error occoured: {e}")
        return render(request, 'signup.html')

        
        

